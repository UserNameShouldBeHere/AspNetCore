var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

DateTime nextNewYear = new DateTime(1, 1, 1);
nextNewYear = nextNewYear.AddYears(DateTime.Now.Year);

app.MapGet("/", () => $"Days to next New Year: {(nextNewYear - DateTime.Now).Days.ToString()}");

app.Run();